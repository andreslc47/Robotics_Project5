#!/bin/sh

xterm -e " source /opt/ros/kinetic/setup.bash ; source ../../../../devel/setup.bash ; roslaunch my_robot world.launch world_file:=/home/andres/Robotics_Project5/src/my_robot/worlds/myworld.world " &
sleep 5
xterm -e " source /opt/ros/kinetic/setup.bash ; source ../../../../devel/setup.bash ; roslaunch my_robot amcl.launch " &
sleep 5
xterm -e " source /opt/ros/kinetic/setup.bash ; source ../../../../devel/setup.bash ; roslaunch turtlebot_rviz_launchers view_navigation.launch " &
sleep 5 
xterm -e " source /opt/ros/kinetic/setup.bash ; source ../../../../devel/setup.bash ; rosrun map_server map_server /home/andres/Robotics_Project5/src/my_robot/maps/myworldmap.yaml " &
sleep 5
xterm -e " source /opt/ros/kinetic/setup.bash ; source ../../../../devel/setup.bash ; rosrun pick_objects pick_objects " &
xterm -e " source /opt/ros/kinetic/setup.bash ; source ../../../../devel/setup.bash ; rosrun add_markers add_markers "





